
const selectLocation = {
  type: "SWITCH_LOCATION",
  city,
  jobs
}

export const SWITCH_LOCATION = "SWITCH_LOCATION";
